document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".flash").forEach((item) => {
    window.setTimeout(() => item.style.opacity = "0.88", 2500);
  });

  const toggle = document.getElementById("themeToggle");
  const icon = document.getElementById("themeIcon");
  const label = document.getElementById("themeLabel");
  const savedTheme = localStorage.getItem("techmanager-theme");

  function applyTheme(theme) {
    const dark = theme === "dark";
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
    if (icon) icon.textContent = dark ? "☀" : "☾";
    if (label) label.textContent = dark ? "Modo claro" : "Modo escuro";
    if (toggle) {
      toggle.setAttribute("aria-label", dark ? "Ativar modo claro" : "Ativar modo escuro");
      toggle.setAttribute("title", dark ? "Ativar modo claro" : "Ativar modo escuro");
    }
  }

  applyTheme(savedTheme === "dark" ? "dark" : "light");
  if (toggle) {
    toggle.addEventListener("click", () => {
      const nextTheme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
      localStorage.setItem("techmanager-theme", nextTheme);
      applyTheme(nextTheme);
    });
  }
});
