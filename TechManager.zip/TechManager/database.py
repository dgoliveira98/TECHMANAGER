import os
import sqlite3
from pathlib import Path

# Em produção, configure DB_PATH para um disco persistente (ex.: /var/data/techmanager.db).
DB_PATH = Path(os.environ.get("DB_PATH", Path(__file__).with_name("techmanager.db")))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


def get_connection():
    conn = sqlite3.connect(DB_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 20000")
    return conn


def _columns(conn, table):
    return {row["name"] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def _add_column(conn, table, name, definition):
    if name not in _columns(conn, table):
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")


def init_db():
    with get_connection() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL COLLATE NOCASE UNIQUE,
            senha_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'usuario' CHECK(role IN ('admin','tecnico','usuario')),
            ativo INTEGER NOT NULL DEFAULT 1,
            email_verificado INTEGER NOT NULL DEFAULT 0,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS ativos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patrimonio TEXT NOT NULL UNIQUE,
            nome TEXT NOT NULL,
            categoria TEXT NOT NULL,
            numero_serie TEXT,
            localizacao TEXT,
            status TEXT NOT NULL DEFAULT 'Disponível',
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS chamados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT,
            categoria TEXT NOT NULL,
            prioridade TEXT NOT NULL DEFAULT 'Média',
            solicitante TEXT NOT NULL,
            solicitante_email TEXT,
            tecnico TEXT,
            status TEXT NOT NULL DEFAULT 'Aberto',
            ativo_id INTEGER,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ativo_id) REFERENCES ativos(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS manutencoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ativo_id INTEGER NOT NULL,
            chamado_id INTEGER,
            tipo TEXT NOT NULL,
            descricao TEXT NOT NULL,
            responsavel TEXT,
            data_manutencao TEXT NOT NULL,
            analise TEXT,
            procedimentos TEXT,
            conservacao TEXT,
            softwares TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ativo_id) REFERENCES ativos(id) ON DELETE CASCADE,
            FOREIGN KEY (chamado_id) REFERENCES chamados(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS historico_chamados (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chamado_id INTEGER NOT NULL,
            usuario_id INTEGER,
            evento TEXT NOT NULL,
            detalhes TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (chamado_id) REFERENCES chamados(id) ON DELETE CASCADE,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS login_tentativas (
            email TEXT PRIMARY KEY COLLATE NOCASE,
            tentativas INTEGER NOT NULL DEFAULT 0,
            bloqueado_ate TEXT,
            atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS auditoria (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER,
            usuario_email TEXT NOT NULL,
            acao TEXT NOT NULL,
            entidade TEXT NOT NULL,
            entidade_id INTEGER,
            detalhes TEXT,
            criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
        );
        """)

        # Migração incremental: mantém bancos anteriores sem apagar registros.
        _add_column(conn, "chamados", "solicitante_email", "TEXT")
        _add_column(conn, "manutencoes", "chamado_id", "INTEGER REFERENCES chamados(id) ON DELETE SET NULL")
        _add_column(conn, "manutencoes", "analise", "TEXT")
        _add_column(conn, "manutencoes", "procedimentos", "TEXT")
        _add_column(conn, "manutencoes", "conservacao", "TEXT")
        _add_column(conn, "manutencoes", "softwares", "TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_chamados_solicitante_email ON chamados(solicitante_email)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_manutencoes_chamado_id ON manutencoes(chamado_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_auditoria_criado_em ON auditoria(criado_em)")
