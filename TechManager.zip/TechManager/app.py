import os
import smtplib
import secrets
import logging
import re
from datetime import datetime, timedelta, timezone
from datetime import timedelta
from email.message import EmailMessage
from functools import wraps
from urllib.parse import urlparse, urljoin

import click
from flask import (
    Flask, render_template, request, redirect, url_for, flash, session,
    g, abort, current_app
)
from flask_wtf.csrf import CSRFProtect
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from database import get_connection, init_db

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY", "dev-only-change-this-secret-before-deploying"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "false").lower() == "true",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    WTF_CSRF_TIME_LIMIT=timedelta(hours=2),
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)
if os.environ.get("FLASK_ENV") == "production" and app.config["SECRET_KEY"] == "dev-only-change-this-secret-before-deploying":
    raise RuntimeError("Configure SECRET_KEY com um valor aleatório forte antes de publicar.")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)
csrf = CSRFProtect(app)
logging.basicConfig(level=logging.INFO)
init_db()

ROLES = {"admin": "Administrador", "tecnico": "Técnico de TI", "usuario": "Usuário comum"}
TICKET_STATUSES = ["Aberto", "Em atendimento", "Aguardando usuário", "Concluído"]
ASSET_STATUSES = ["Disponível", "Em uso", "Em manutenção", "Descartado"]


def token_serializer(salt):
    return URLSafeTimedSerializer(app.config["SECRET_KEY"], salt=salt)


def safe_redirect_target(target):
    if not target:
        return False
    host_url = urlparse(request.host_url)
    redirect_url = urlparse(urljoin(request.host_url, target))
    return redirect_url.scheme in ("http", "https") and host_url.netloc == redirect_url.netloc


def send_email(to_email, subject, body):
    host = os.environ.get("SMTP_HOST")
    if not host:
        if os.environ.get("FLASK_DEBUG", "false").lower() == "true":
            app.logger.warning("SMTP não configurado. Link de desenvolvimento para %s:\n%s", to_email, body)
            return True
        app.logger.error("SMTP_HOST não configurado; e-mail não enviado.")
        return False

    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = os.environ.get("MAIL_FROM", os.environ.get("SMTP_USER", "no-reply@techmanager.local"))
    message["To"] = to_email
    message.set_content(body)
    port = int(os.environ.get("SMTP_PORT", "587"))
    username = os.environ.get("SMTP_USER")
    password = os.environ.get("SMTP_PASSWORD")
    try:
        with smtplib.SMTP(host, port, timeout=20) as server:
            server.ehlo()
            if os.environ.get("SMTP_USE_TLS", "true").lower() == "true":
                server.starttls()
                server.ehlo()
            if username and password:
                server.login(username, password)
            server.send_message(message)
        return True
    except Exception:
        app.logger.exception("Falha ao enviar e-mail para %s", to_email)
        return False


def make_email_link(endpoint, email, salt):
    token = token_serializer(salt).dumps(email)
    return url_for(endpoint, token=token, _external=True)


def current_user():
    return getattr(g, "user", None)


@app.before_request
def load_logged_in_user():
    user_id = session.get("user_id")
    g.user = None
    if user_id:
        with get_connection() as conn:
            g.user = conn.execute(
                "SELECT id, nome, email, role, ativo, email_verificado FROM usuarios WHERE id = ?",
                (user_id,)
            ).fetchone()
        if not g.user or not g.user["ativo"]:
            session.clear()
            g.user = None


@app.context_processor
def inject_user():
    return {"current_user": current_user(), "role_names": ROLES}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Entre na sua conta para continuar.", "aviso")
            return redirect(url_for("login", next=request.url))
        if not current_user()["email_verificado"]:
            session.clear()
            flash("Confirme seu e-mail antes de acessar o sistema.", "aviso")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if current_user()["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def audit(action, entity, entity_id=None, details=""):
    user = current_user()
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO auditoria (usuario_id, usuario_email, acao, entidade, entidade_id, detalhes) VALUES (?, ?, ?, ?, ?, ?)",
            (user["id"] if user else None, user["email"] if user else "sistema",
             action, entity, entity_id, details[:500])
        )


@app.after_request
def set_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if app.config["SESSION_COOKIE_SECURE"]:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


@app.route("/")
@login_required
def dashboard():
    if current_user()["role"] == "usuario":
        return redirect(url_for("chamados"))
    with get_connection() as conn:
        total_ativos = conn.execute("SELECT COUNT(*) FROM ativos").fetchone()[0]
        ativos_manutencao = conn.execute(
            "SELECT COUNT(*) FROM ativos WHERE status = 'Em manutenção'"
        ).fetchone()[0]
        chamados_abertos = conn.execute(
            "SELECT COUNT(*) FROM chamados WHERE status != 'Concluído'"
        ).fetchone()[0]
        ultimos_chamados = conn.execute("""
            SELECT c.*, a.nome AS ativo_nome
            FROM chamados c LEFT JOIN ativos a ON a.id = c.ativo_id
            ORDER BY c.id DESC LIMIT 5
        """).fetchall()
    return render_template(
        "dashboard.html", total_ativos=total_ativos,
        ativos_manutencao=ativos_manutencao,
        chamados_abertos=chamados_abertos, ultimos_chamados=ultimos_chamados
    )


@app.route("/cadastro", methods=["GET", "POST"])
def cadastro():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        confirmar = request.form.get("confirmar_senha", "")
        if not nome or not email or len(nome) > 120 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            flash("Informe um nome válido e um e-mail.", "erro")
        elif len(senha) < 10:
            flash("A senha deve ter pelo menos 10 caracteres.", "erro")
        elif senha != confirmar:
            flash("As senhas não coincidem.", "erro")
        else:
            try:
                with get_connection() as conn:
                    cur = conn.execute(
                        """INSERT INTO usuarios (nome, email, senha_hash, role, ativo, email_verificado)
                           VALUES (?, ?, ?, 'usuario', 1, 0)""",
                        (nome, email, generate_password_hash(senha))
                    )
                    user_id = cur.lastrowid
                link = make_email_link("verificar_email", email, "email-verification")
                body = f"Olá, {nome}!\n\nConfirme seu endereço de e-mail para ativar sua conta no TechManager:\n{link}\n\nO link expira em 1 hora. Se você não criou esta conta, ignore esta mensagem."
                if not send_email(email, "Confirme seu e-mail - TechManager", body):
                    with get_connection() as conn:
                        conn.execute("DELETE FROM usuarios WHERE id = ?", (user_id,))
                    flash("Não foi possível enviar o e-mail de confirmação. Tente novamente mais tarde.", "erro")
                else:
                    flash("Cadastro criado! Enviamos um link de confirmação para seu e-mail.", "sucesso")
                    return redirect(url_for("login"))
            except Exception as exc:
                if "UNIQUE" in str(exc).upper():
                    flash("Este e-mail já está cadastrado.", "erro")
                else:
                    app.logger.exception("Erro no cadastro")
                    flash("Não foi possível concluir o cadastro.", "erro")
    return render_template("auth/cadastro.html")


@app.route("/verificar-email/<token>")
def verificar_email(token):
    try:
        email = token_serializer("email-verification").loads(token, max_age=3600)
    except SignatureExpired:
        flash("O link de confirmação expirou. Solicite um novo cadastro ou entre em contato com o administrador.", "erro")
        return redirect(url_for("login"))
    except BadSignature:
        abort(400)
    with get_connection() as conn:
        user = conn.execute("SELECT id, email_verificado FROM usuarios WHERE email = ?", (email,)).fetchone()
        if not user:
            flash("Conta não encontrada.", "erro")
        elif user["email_verificado"]:
            flash("Seu e-mail já foi confirmado. Faça login.", "sucesso")
        else:
            conn.execute("UPDATE usuarios SET email_verificado = 1 WHERE id = ?", (user["id"],))
            flash("E-mail confirmado! Agora você pode entrar.", "sucesso")
    return redirect(url_for("login"))


@app.route("/reenviar-confirmacao", methods=["GET", "POST"])
def reenviar_confirmacao():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        with get_connection() as conn:
            user = conn.execute(
                "SELECT nome, email, email_verificado FROM usuarios WHERE email = ? AND ativo = 1",
                (email,)
            ).fetchone()
        if user and not user["email_verificado"]:
            link = make_email_link("verificar_email", email, "email-verification")
            body = f"Olá, {user['nome']}!\\n\\nConfirme seu e-mail no TechManager:\\n{link}\\n\\nO link expira em 1 hora."
            send_email(email, "Confirme seu e-mail - TechManager", body)
        flash("Se houver uma conta pendente para esse endereço, enviaremos um novo link.", "sucesso")
        return redirect(url_for("login"))
    return render_template("auth/reenviar_confirmacao.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "")
        now = datetime.now(timezone.utc)
        now_text = now.isoformat()
        with get_connection() as conn:
            attempt = conn.execute("SELECT * FROM login_tentativas WHERE email = ?", (email,)).fetchone()
            user = conn.execute("SELECT * FROM usuarios WHERE email = ?", (email,)).fetchone()
        if attempt and attempt["bloqueado_ate"] and attempt["bloqueado_ate"] > now_text:
            flash("Não foi possível entrar. Aguarde alguns minutos e tente novamente.", "erro")
        elif not user or not check_password_hash(user["senha_hash"], senha):
            with get_connection() as conn:
                count = (attempt["tentativas"] if attempt else 0) + 1
                locked_until = (now + timedelta(minutes=15)).isoformat() if count >= 5 else None
                conn.execute("""
                    INSERT INTO login_tentativas (email, tentativas, bloqueado_ate, atualizado_em)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(email) DO UPDATE SET
                      tentativas=excluded.tentativas,
                      bloqueado_ate=excluded.bloqueado_ate,
                      atualizado_em=CURRENT_TIMESTAMP
                """, (email, count, locked_until))
            flash("E-mail ou senha inválidos.", "erro")
        elif not user["ativo"]:
            flash("Esta conta está desativada. Procure o administrador.", "erro")
        elif not user["email_verificado"]:
            flash("Confirme seu e-mail antes de entrar.", "aviso")
        else:
            with get_connection() as conn:
                conn.execute("DELETE FROM login_tentativas WHERE email = ?", (email,))
            session.clear()
            session["user_id"] = user["id"]
            session.permanent = True
            g.user = user
            audit("login", "usuario", user["id"], "Login realizado")
            next_url = request.args.get("next")
            return redirect(next_url if safe_redirect_target(next_url) else url_for("dashboard"))
    return render_template("auth/login.html")


@app.route("/sair", methods=["POST"])
@login_required
def logout():
    audit("logout", "usuario", current_user()["id"], "Logout realizado")
    session.clear()
    flash("Você saiu do TechManager.", "sucesso")
    return redirect(url_for("login"))


@app.route("/recuperar-senha", methods=["GET", "POST"])
def recuperar_senha():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        with get_connection() as conn:
            user = conn.execute("SELECT nome, email, senha_hash FROM usuarios WHERE email = ? AND ativo = 1", (email,)).fetchone()
        # Resposta genérica evita revelar se um endereço possui cadastro.
        if user:
            link = url_for("redefinir_senha", token=token_serializer("password-reset").dumps({"email": email, "senha_hash": user["senha_hash"]}), _external=True)
            body = f"Olá, {user['nome']}!\n\nUse o link abaixo para redefinir sua senha do TechManager:\n{link}\n\nO link expira em 30 minutos. Se você não solicitou a redefinição, ignore esta mensagem."
            send_email(email, "Redefinição de senha - TechManager", body)
        flash("Se o e-mail estiver cadastrado, enviaremos as instruções de recuperação.", "sucesso")
        return redirect(url_for("login"))
    return render_template("auth/recuperar_senha.html")


@app.route("/redefinir-senha/<token>", methods=["GET", "POST"])
def redefinir_senha(token):
    try:
        payload = token_serializer("password-reset").loads(token, max_age=1800)
        email = payload["email"]
    except SignatureExpired:
        flash("O link expirou. Solicite uma nova recuperação de senha.", "erro")
        return redirect(url_for("recuperar_senha"))
    except BadSignature:
        abort(400)
    with get_connection() as conn:
        user = conn.execute("SELECT id, senha_hash FROM usuarios WHERE email = ? AND ativo = 1", (email,)).fetchone()
    if not user or user["senha_hash"] != payload.get("senha_hash"):
        abort(404)
    if request.method == "POST":
        senha = request.form.get("senha", "")
        confirmar = request.form.get("confirmar_senha", "")
        if len(senha) < 10:
            flash("A senha deve ter pelo menos 10 caracteres.", "erro")
        elif senha != confirmar:
            flash("As senhas não coincidem.", "erro")
        else:
            with get_connection() as conn:
                conn.execute("UPDATE usuarios SET senha_hash = ? WHERE id = ?", (generate_password_hash(senha), user["id"]))
            flash("Senha alterada. Faça login com a nova senha.", "sucesso")
            return redirect(url_for("login"))
    return render_template("auth/redefinir_senha.html")


@app.route("/ativos", methods=["GET", "POST"])
@roles_required("admin", "tecnico")
def ativos():
    if request.method == "POST":
        patrimonio = request.form.get("patrimonio", "").strip()
        nome = request.form.get("nome", "").strip()
        categoria = request.form.get("categoria", "").strip()
        if not patrimonio or not nome or not categoria:
            flash("Preencha patrimônio, nome e categoria.", "erro")
            return redirect(url_for("ativos"))
        try:
            with get_connection() as conn:
                cur = conn.execute("""
                    INSERT INTO ativos (patrimonio, nome, categoria, numero_serie, localizacao, status)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (patrimonio, nome, categoria,
                      request.form.get("numero_serie", "").strip(),
                      request.form.get("localizacao", "").strip(),
                      request.form.get("status", "Disponível")))
            audit("cadastro", "ativo", cur.lastrowid, f"Patrimônio {patrimonio}")
            flash("Equipamento cadastrado com sucesso.", "sucesso")
        except Exception as exc:
            if "UNIQUE" in str(exc).upper():
                flash("Não foi possível cadastrar. O patrimônio já existe.", "erro")
            else:
                app.logger.exception("Erro ao cadastrar ativo")
                flash("Não foi possível cadastrar o equipamento.", "erro")
        return redirect(url_for("ativos"))

    busca = request.args.get("q", "").strip()
    with get_connection() as conn:
        if busca:
            lista = conn.execute("""
                SELECT * FROM ativos WHERE nome LIKE ? OR patrimonio LIKE ? OR categoria LIKE ?
                ORDER BY id DESC
            """, (f"%{busca}%", f"%{busca}%", f"%{busca}%")).fetchall()
        else:
            lista = conn.execute("SELECT * FROM ativos ORDER BY id DESC").fetchall()
    return render_template("ativos.html", ativos=lista, busca=busca)


@app.post("/ativos/<int:ativo_id>/status")
@roles_required("admin", "tecnico")
def atualizar_status_ativo(ativo_id):
    status = request.form.get("status")
    if status in ASSET_STATUSES:
        with get_connection() as conn:
            conn.execute("UPDATE ativos SET status = ? WHERE id = ?", (status, ativo_id))
        audit("alteração de status", "ativo", ativo_id, status)
        flash("Situação do equipamento atualizada.", "sucesso")
    return redirect(url_for("ativos"))


@app.post("/ativos/<int:ativo_id>/excluir")
@roles_required("admin")
def excluir_ativo(ativo_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM ativos WHERE id = ?", (ativo_id,))
    audit("exclusão", "ativo", ativo_id, "Ativo excluído")
    flash("Equipamento excluído.", "sucesso")
    return redirect(url_for("ativos"))


@app.route("/chamados", methods=["GET", "POST"])
@login_required
def chamados():
    user = current_user()
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        categoria = request.form.get("categoria", "").strip()
        if not titulo or not categoria:
            flash("Preencha título e categoria.", "erro")
            return redirect(url_for("chamados"))
        ativo_id = request.form.get("ativo_id") or None
        if user["role"] == "usuario":
            ativo_id = None
            prioridade = "Média"
            tecnico = None
        else:
            prioridade = request.form.get("prioridade", "Média")
            if prioridade not in ["Baixa", "Média", "Alta", "Crítica"]:
                prioridade = "Média"
            tecnico = request.form.get("tecnico", "").strip() or None
        with get_connection() as conn:
            cur = conn.execute("""
                INSERT INTO chamados
                (titulo, descricao, categoria, prioridade, solicitante, solicitante_email, tecnico, ativo_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (titulo, request.form.get("descricao", "").strip(), categoria,
                  prioridade, user["nome"], user["email"], tecnico, ativo_id))
            chamado_id = cur.lastrowid
            conn.execute(
                "INSERT INTO historico_chamados (chamado_id, usuario_id, evento, detalhes) VALUES (?, ?, ?, ?)",
                (chamado_id, user["id"], "Chamado aberto", titulo)
            )
        audit("abertura", "chamado", chamado_id, titulo)
        flash("Chamado aberto com sucesso.", "sucesso")
        return redirect(url_for("chamados"))

    with get_connection() as conn:
        if user["role"] == "usuario":
            lista = conn.execute("""
                SELECT c.*, a.nome AS ativo_nome FROM chamados c
                LEFT JOIN ativos a ON a.id = c.ativo_id
                WHERE c.solicitante_email = ? ORDER BY c.id DESC
            """, (user["email"],)).fetchall()
        else:
            lista = conn.execute("""
                SELECT c.*, a.nome AS ativo_nome FROM chamados c
                LEFT JOIN ativos a ON a.id = c.ativo_id ORDER BY c.id DESC
            """).fetchall()
        lista_ativos = conn.execute("SELECT id, nome, patrimonio FROM ativos WHERE status != 'Descartado' ORDER BY nome").fetchall()
        resumo_status = {
            status: sum(1 for c in lista if c["status"] == status)
            for status in TICKET_STATUSES
        }
        historicos = {}
        for chamado in lista:
            historicos[chamado["id"]] = conn.execute("""
                SELECT h.evento, h.detalhes, h.criado_em, COALESCE(u.nome, 'Sistema') AS autor
                FROM historico_chamados h
                LEFT JOIN usuarios u ON u.id = h.usuario_id
                WHERE h.chamado_id = ? ORDER BY h.id DESC
            """, (chamado["id"],)).fetchall()
    return render_template("chamados.html", chamados=lista, ativos=lista_ativos,
                           resumo_status=resumo_status, historicos=historicos)


@app.post("/chamados/<int:chamado_id>/status")
@roles_required("admin", "tecnico")
def atualizar_status_chamado(chamado_id):
    status = request.form.get("status")
    if status not in TICKET_STATUSES:
        abort(400)
    with get_connection() as conn:
        ticket = conn.execute("SELECT id FROM chamados WHERE id = ?", (chamado_id,)).fetchone()
        if not ticket:
            abort(404)
        if status == "Concluído":
            maintenance = conn.execute("SELECT id FROM manutencoes WHERE chamado_id = ?", (chamado_id,)).fetchone()
            if not maintenance:
                flash("Para concluir, registre primeiro uma manutenção vinculada a este chamado.", "erro")
                return redirect(url_for("chamados"))
        conn.execute("UPDATE chamados SET status = ? WHERE id = ?", (status, chamado_id))
        conn.execute(
            "INSERT INTO historico_chamados (chamado_id, usuario_id, evento, detalhes) VALUES (?, ?, ?, ?)",
            (chamado_id, current_user()["id"], "Status alterado", status)
        )
    audit("alteração de status", "chamado", chamado_id, status)
    flash("Status do chamado atualizado.", "sucesso")
    return redirect(url_for("chamados"))


@app.route("/manutencoes", methods=["GET", "POST"])
@roles_required("admin", "tecnico")
def manutencoes():
    if request.method == "POST":
        ativo_id = request.form.get("ativo_id")
        chamado_id = request.form.get("chamado_id") or None
        tipo = request.form.get("tipo")
        descricao = request.form.get("descricao", "").strip()
        analise = request.form.get("analise", "").strip()
        procedimentos = request.form.get("procedimentos", "").strip()
        conservacao = request.form.get("conservacao", "").strip()
        softwares = request.form.get("softwares", "").strip()
        data = request.form.get("data_manutencao")
        if not ativo_id or not tipo or not descricao or not data or not analise or not procedimentos:
            flash("Preencha equipamento, tipo, data, análise técnica e procedimentos realizados.", "erro")
            return redirect(url_for("manutencoes"))
        with get_connection() as conn:
            if chamado_id:
                ticket = conn.execute("SELECT id, ativo_id FROM chamados WHERE id = ?", (chamado_id,)).fetchone()
                if not ticket:
                    flash("O chamado selecionado não existe.", "erro")
                    return redirect(url_for("manutencoes"))
                if ticket["ativo_id"] and str(ticket["ativo_id"]) != str(ativo_id):
                    flash("O equipamento da manutenção precisa ser o mesmo vinculado ao chamado.", "erro")
                    return redirect(url_for("manutencoes"))
                if not ticket["ativo_id"]:
                    conn.execute("UPDATE chamados SET ativo_id = ? WHERE id = ?", (ativo_id, chamado_id))
            cur = conn.execute("""
                INSERT INTO manutencoes
                (ativo_id, chamado_id, tipo, descricao, responsavel, data_manutencao,
                 analise, procedimentos, conservacao, softwares)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (ativo_id, chamado_id, tipo, descricao, current_user()["nome"], data,
                  analise, procedimentos, conservacao, softwares))
            maintenance_id = cur.lastrowid
            if chamado_id:
                conn.execute(
                    "INSERT INTO historico_chamados (chamado_id, usuario_id, evento, detalhes) VALUES (?, ?, ?, ?)",
                    (chamado_id, current_user()["id"], "Manutenção registrada", f"Manutenção #{maintenance_id}")
                )
        audit("cadastro", "manutenção", maintenance_id, f"Chamado {chamado_id or 'não vinculado'}")
        flash("Manutenção registrada.", "sucesso")
        return redirect(url_for("manutencoes"))

    with get_connection() as conn:
        lista_ativos = conn.execute("SELECT id, nome, patrimonio FROM ativos WHERE status != 'Descartado' ORDER BY nome").fetchall()
        chamados_abertos = conn.execute(
            "SELECT id, titulo FROM chamados WHERE status != 'Concluído' ORDER BY id DESC"
        ).fetchall()
        registros = conn.execute("""
            SELECT m.*, a.nome AS ativo_nome, a.patrimonio, c.titulo AS chamado_titulo
            FROM manutencoes m JOIN ativos a ON a.id = m.ativo_id
            LEFT JOIN chamados c ON c.id = m.chamado_id
            ORDER BY m.data_manutencao DESC, m.id DESC
        """).fetchall()
    return render_template("manutencoes.html", ativos=lista_ativos,
                           manutencoes=registros, chamados_abertos=chamados_abertos)


@app.route("/admin/usuarios")
@roles_required("admin")
def admin_usuarios():
    with get_connection() as conn:
        users = conn.execute(
            "SELECT id, nome, email, role, ativo, email_verificado, criado_em FROM usuarios ORDER BY criado_em DESC"
        ).fetchall()
    return render_template("admin_usuarios.html", usuarios=users)


@app.post("/admin/usuarios/<int:user_id>/atualizar")
@roles_required("admin")
def admin_atualizar_usuario(user_id):
    role = request.form.get("role")
    ativo = 1 if request.form.get("ativo") == "1" else 0
    if role not in ROLES:
        abort(400)
    if user_id == current_user()["id"] and not ativo:
        flash("Você não pode desativar sua própria conta.", "erro")
        return redirect(url_for("admin_usuarios"))
    with get_connection() as conn:
        conn.execute("UPDATE usuarios SET role = ?, ativo = ? WHERE id = ?", (role, ativo, user_id))
    audit("alteração", "usuario", user_id, f"Perfil={role}; ativo={ativo}")
    flash("Usuário atualizado.", "sucesso")
    return redirect(url_for("admin_usuarios"))


@app.errorhandler(403)
def forbidden(_error):
    return render_template("errors/403.html"), 403


@app.errorhandler(404)
def not_found(_error):
    if current_user():
        return render_template("errors/404.html"), 404
    return render_template("auth/error.html", titulo="Página não encontrada",
                           mensagem="O endereço solicitado não existe."), 404


@app.cli.command("create-admin")
@click.option("--nome", prompt="Nome do administrador")
@click.option("--email", prompt="E-mail do administrador")
@click.password_option()
def create_admin(nome, email, password):
    """Cria ou promove uma conta administrativa inicial."""
    email = email.strip().lower()
    if len(password) < 10:
        raise click.ClickException("A senha deve ter pelo menos 10 caracteres.")
    with get_connection() as conn:
        existing = conn.execute("SELECT id FROM usuarios WHERE email = ?", (email,)).fetchone()
        if existing:
            conn.execute(
                "UPDATE usuarios SET nome=?, senha_hash=?, role='admin', ativo=1, email_verificado=1 WHERE id=?",
                (nome.strip(), generate_password_hash(password), existing["id"])
            )
            click.echo("Conta existente atualizada e promovida a administradora.")
        else:
            conn.execute(
                "INSERT INTO usuarios (nome, email, senha_hash, role, ativo, email_verificado) VALUES (?, ?, ?, 'admin', 1, 1)",
                (nome.strip(), email, generate_password_hash(password))
            )
            click.echo("Administrador criado com sucesso.")


if __name__ == "__main__":
    app.run(debug=os.environ.get("FLASK_DEBUG", "false").lower() == "true")
