# TechManager

Sistema web acadêmico para gestão de ativos de TI, chamados técnicos e manutenções.

## Requisitos
- Python 3.10 ou superior
- pip

## Executar localmente no Windows

1. Extraia a pasta `TechManager`.
2. Abra o PowerShell dentro da pasta.
3. Crie e ative o ambiente virtual:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Instale as dependências:

   ```powershell
   python -m pip install -r requirements.txt
   ```

5. Para testar cadastro e verificação de e-mail localmente, configure o modo de desenvolvimento:

   ```powershell
   $env:FLASK_DEBUG="true"
   python app.py
   ```

   Sem SMTP, o link de confirmação e o link de recuperação serão exibidos no terminal somente nesse modo de desenvolvimento.

6. Acesse `http://127.0.0.1:5000`.

## Criar o primeiro administrador

Com o ambiente virtual ativado, execute:

```powershell
flask --app app create-admin
```

Informe nome, e-mail e senha quando solicitado. A conta criada será verificada e terá perfil de administrador. **Não existe cadastro público de administrador:** novos cadastros recebem sempre o perfil `usuario`.

## Perfis

- `admin`: gerenciamento completo, incluindo usuários.
- `tecnico`: ativos, chamados e manutenções.
- `usuario`: abre chamados e acompanha apenas os próprios chamados.

## Autenticação e segurança

- Cadastro público com e-mail e senha.
- Confirmação de e-mail por link assinado, com validade de 1 hora.
- Senhas armazenadas com hash seguro do Werkzeug.
- Recuperação de senha por link assinado, válido por 30 minutos.
- Sessões com cookie HTTPOnly, SameSite e opção Secure em HTTPS.
- Bloqueio temporário de tentativas repetidas de login (5 falhas bloqueiam por 15 minutos).
- Reenvio do link de confirmação de e-mail.
- Proteção CSRF nos formulários.
- Controle de acesso por perfil no servidor.
- Registro de operações na tabela `auditoria`.
- Histórico de eventos dos chamados.
- Chamado só pode ser concluído depois de uma manutenção vinculada.
- Senha mínima de 10 caracteres.

## Configuração de e-mail (SMTP)

Configure as variáveis de ambiente abaixo na hospedagem. Não coloque credenciais no código ou no GitHub:

- `SMTP_HOST`: servidor SMTP.
- `SMTP_PORT`: normalmente 587.
- `SMTP_USER`: usuário SMTP.
- `SMTP_PASSWORD`: senha ou senha de aplicativo.
- `SMTP_USE_TLS`: `true` (padrão) ou `false`, conforme o provedor.
- `MAIL_FROM`: remetente autorizado.

Sem SMTP, em produção os e-mails de confirmação e recuperação não serão enviados. O modo de desenvolvimento permite testar pelos links exibidos no terminal.

## Preparação para hospedagem

Dependências de produção incluídas: Gunicorn e Flask-WTF.

Comando de inicialização recomendado:

```bash
gunicorn app:app
```

Variáveis necessárias/recomendadas na hospedagem:

- `SECRET_KEY`: valor aleatório forte e exclusivo.
- `COOKIE_SECURE=true`: habilita cookie Secure em HTTPS.
- `DB_PATH`: caminho de banco em disco persistente, por exemplo `/var/data/techmanager.db`.
- Variáveis SMTP listadas acima.

**Persistência:** SQLite deve ficar em um disco persistente da hospedagem. Não use o sistema de arquivos efêmero do serviço para armazenar o banco. Para múltiplas instâncias simultâneas, prefira PostgreSQL.

## Banco de dados existente

O `database.py` executa migrações incrementais para adicionar as novas colunas e tabelas sem apagar os registros antigos. Antes de atualizar uma instalação existente, faça uma cópia de segurança do arquivo `techmanager.db`.

O ZIP distribuído não inclui banco de dados com dados pessoais. Copie o banco existente para a pasta do projeto ou configure `DB_PATH` para apontar para o arquivo correto.

## Observações antes de produção

1. Configure `SECRET_KEY` forte e SMTP funcional.
2. Configure `COOKIE_SECURE=true` quando o site estiver em HTTPS.
3. Use armazenamento persistente para o banco.
4. Crie o administrador inicial pelo comando CLI.
5. Teste cadastro, confirmação, login, recuperação de senha e permissões com contas de cada perfil.
6. Faça backup periódico do banco de dados.
